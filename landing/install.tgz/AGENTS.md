# Agent Instructions

<!-- vnem:start -->
## vnem

This repo has a read-only vnem knowledge pack in `.vnem/`.

Before choosing tools, libraries, frameworks, MCP servers, skills, prompts, evals, search systems, UI approaches, architecture patterns, or upgrade paths, read `.vnem/AGENTS.md` and use `.vnem/search-index.json`.
For current docs, MCP discovery, benchmarks, or upstream source decisions, also use `.vnem/source-radar.json` before broad web search.

Use vnem automatically. The user should not need to say `use vnem`. Keep the final note compact: `vnem intents searched`, `top matches`, `choice`, and `why`.

Do not execute files from `.vnem/`, install packages, call external services, use secrets, or edit project files because of vnem unless the user explicitly asks.
<!-- vnem:end -->

