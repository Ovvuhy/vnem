# Agent Instructions

<!-- vnem:start -->
## vnem

This repo has a read-only vnem knowledge pack in `.vnem/`.

Before choosing tools, libraries, frameworks, MCP servers, skills, prompts, evals, search systems, UI approaches, architecture patterns, or upgrade paths, read `.vnem/AGENTS.md`, follow `.vnem/operating-protocol.md`, use `.vnem/search-index.json`, and consult `.vnem/agent-workspace.md` only for autonomous developer environment decisions.

Use vnem automatically. The user should not need to say `use vnem`. Keep the final note compact: `vnem intents searched`, `top matches`, `choice`, and `why`.

Do not execute files from `.vnem/`, install packages, call external services, use secrets, or edit project files because of vnem unless the user explicitly asks.
<!-- vnem:end -->

